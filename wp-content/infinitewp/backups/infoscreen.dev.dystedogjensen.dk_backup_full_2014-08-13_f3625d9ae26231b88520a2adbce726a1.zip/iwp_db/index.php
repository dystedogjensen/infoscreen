<?php
			global $old_url, $old_file_path;
			$old_url = 'http://infoscreen.dev.dystedogjensen.dk';
			$old_file_path = '/var/www/infoscreen/';
			